const {updateBCAOtpCode} = require("./updateBCAOtpCode")
const {getBCAFromDB} = require("./getBCAFromDB")


module.exports = {
    updateBCAOtpCode,
    getBCAFromDB
}
