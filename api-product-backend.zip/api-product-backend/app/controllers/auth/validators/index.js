const { validateLogin } = require('./validateLogin')
const { validateRefreshToken } = require('./validateRefreshToken')
module.exports = {
  validateLogin,
  validateRefreshToken
}
