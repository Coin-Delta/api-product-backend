#!/bin/bash
cd /home/ubuntu/Background-check-backend
npm i --save
pm2 start server.js
