apt-get update -y
