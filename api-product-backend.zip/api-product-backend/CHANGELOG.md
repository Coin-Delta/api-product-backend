## v1.0.0 (October 3, 2022)

*   First stable release
